
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/reels-check.mjs
import { GoogleGenerativeAI } from "@google/generative-ai";
var reels_check_default = async (req, context) => {
  if (req.method === "OPTIONS") {
    return new Response("OK", {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      }
    });
  }
  try {
    const body = await req.json();
    const { hook, script, caption, focus, knowledgeBase } = body;
    const systemPrompt = `\uB2F9\uC2E0\uC740 '\uC870\uC26C\uC758 \uCF58\uD150\uCE20 \uB9C8\uC2A4\uD130\uD074\uB798\uC2A4'\uC758 \uC218\uC11D \uCF54\uCE58\uC785\uB2C8\uB2E4.
\uC218\uAC15\uC0DD\uC774 \uC81C\uCD9C\uD55C \uB9B4\uC2A4 \uAE30\uD68D\uC548\uC744 [\uC9C0\uC2DD \uBCA0\uC774\uC2A4]\uC758 '\uCCA8\uC0AD \uC2DC\uC2A4\uD15C' \uAE30\uC900\uC5D0 \uB530\uB77C \uB0C9\uCCA0\uD558\uBA74\uC11C\uB3C4 \uB530\uB73B\uD558\uAC8C \uC810\uAC80\uD574\uC57C \uD569\uB2C8\uB2E4.

[\uC218\uAC15\uC0DD \uC81C\uCD9C \uB0B4\uC6A9]
1. \uD6C4\uD0B9 \uC81C\uBAA9: ${hook}
2. \uB9B4\uC2A4 \uB300\uBCF8: ${script}
3. \uB9B4\uC2A4 \uCEA1\uC158: ${caption}
4. \uAC15\uC870/\uC2E0\uACBD\uC4F4 \uC810: ${focus}

[\uC810\uAC80 \uAC00\uC774\uB4DC\uB77C\uC778]
1. \uBC18\uB4DC\uC2DC [\uC9C0\uC2DD \uBCA0\uC774\uC2A4]\uC758 '21. \uC790\uB3D9 \uACFC\uC81C \uCCA8\uC0AD \uC2DC\uC2A4\uD15C' \uD615\uC2DD\uC744 \uB530\uB974\uC138\uC694.
2. [\u{1F4CB} \uC870\uC26C\uC758 \uCCA8\uC0AD \uB9AC\uD3EC\uD2B8]\uB77C\uB294 \uC81C\uBAA9\uC73C\uB85C \uC2DC\uC791\uD558\uC138\uC694.
3. \uCD1D\uC810 10\uC810 \uB9CC\uC810\uC73C\uB85C \uC810\uC218\uB97C \uB9E4\uAE30\uACE0, \uD56D\uBAA9\uBCC4(\uD6C4\uD0B9 3, \uAC00\uCE58 2, \uC99D\uAC70 2, \uB9AC\uD150\uC158/CTA 3) \uADFC\uAC70\uB97C \uC4F0\uC138\uC694.
4. \uC798\uD55C \uBD80\uBD84\uC740 \uD655\uC2E4\uD788 \uCE6D\uCC2C\uD558\uC5EC \uB3D9\uAE30\uB97C \uBD80\uC5EC\uD558\uACE0, \uBD80\uC871\uD55C \uBD80\uBD84\uC740 \uC870\uC26C\uC758 \uCCA0\uD559\uC744 \uB2F4\uC544 \uB0A0\uCE74\uB86D\uAC8C \uC218\uC815 \uC81C\uC548\uD558\uC138\uC694.
5. \uC774\uBAA8\uC9C0\uC640 \uBCFC\uB4DC\uCCB4 \uC0AC\uC6A9\uC744 \uAE08\uC9C0\uD558\uACE0 \uC624\uC9C1 \uD3C9\uBB38 \uB9C8\uD06C\uB2E4\uC6B4\uC73C\uB85C\uB9CC \uC791\uC131\uD558\uC138\uC694. (\uC904\uBC14\uAFC8 \uBE48 \uC904 2\uBC88 \uC0AC\uC6A9 \uD544\uC218)

[\uC9C0\uC2DD \uBCA0\uC774\uC2A4]
${knowledgeBase || ""}`;
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
    const result = await model.generateContentStream(systemPrompt);
    const stream = new ReadableStream({
      async start(controller) {
        try {
          for await (const chunk of result.stream) {
            controller.enqueue(new TextEncoder().encode(chunk.text()));
          }
          controller.close();
        } catch (e) {
          controller.error(e);
        }
      }
    });
    return new Response(stream, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Access-Control-Allow-Origin": "*"
      }
    });
  } catch (error) {
    console.error("Reels Check Error:", error);
    return new Response(JSON.stringify({ error: error.message }), { status: 500 });
  }
};
export {
  reels_check_default as default
};
