
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/chat.mjs
import { GoogleGenerativeAI } from "@google/generative-ai";
var chat_default = async (req, context) => {
  if (req.method === "OPTIONS") {
    return new Response("OK", {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      }
    });
  }
  try {
    const body = await req.json();
    const { messages, knowledgeBase } = body;
    const systemPrompt = `\uB2F9\uC2E0\uC740 '\uC870\uC26C\uC758 \uCF58\uD150\uCE20 \uB9C8\uC2A4\uD130\uD074\uB798\uC2A4'\uC758 AI \uC870\uAD50\uC785\uB2C8\uB2E4.
[\uB2F5\uBCC0 \uADDC\uCE59]
- \uC81C\uACF5\uB41C [\uC9C0\uC2DD \uBCA0\uC774\uC2A4] \uB0B4\uC6A9\uC744 1\uC21C\uC704\uB85C \uCC38\uACE0\uD558\uC138\uC694.
- \uC808\uB300 \uC774\uBAA8\uC9C0(Emoji)\uB97C \uC0AC\uC6A9\uD558\uC9C0 \uB9C8\uC138\uC694.
- \uC808\uB300 \uBCFC\uB4DC\uCCB4(**) \uB4F1 \uB9C8\uD06C\uB2E4\uC6B4 \uD14D\uC2A4\uD2B8 \uAC15\uC870\uB97C \uC0AC\uC6A9\uD558\uC9C0 \uB9C8\uC138\uC694.
- \uCE5C\uADFC\uD55C \uC874\uB313\uB9D0(~\uD574\uC694)\uC744 \uC0AC\uC6A9\uD558\uC138\uC694.

[\uC9C0\uC2DD \uBCA0\uC774\uC2A4]
${knowledgeBase || ""}`;
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({
      model: "gemini-2.5-flash",
      systemInstruction: systemPrompt
    });
    const history = messages.slice(0, -1).map((msg) => ({
      role: msg.role === "user" ? "user" : "model",
      parts: [{ text: msg.content }]
    }));
    const lastMessage = messages[messages.length - 1].content;
    const chat = model.startChat({ history });
    const result = await chat.sendMessageStream(lastMessage);
    const stream = new ReadableStream({
      async start(controller) {
        try {
          for await (const chunk of result.stream) {
            controller.enqueue(new TextEncoder().encode(chunk.text()));
          }
          controller.close();
        } catch (e) {
          controller.error(e);
        }
      }
    });
    return new Response(stream, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Access-Control-Allow-Origin": "*"
      }
    });
  } catch (error) {
    console.error("Chat Error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  }
};
export {
  chat_default as default
};
