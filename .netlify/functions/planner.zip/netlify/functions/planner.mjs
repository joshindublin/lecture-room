
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/planner.mjs
import { GoogleGenerativeAI } from "@google/generative-ai";
var planner_default = async (req, context) => {
  if (req.method === "OPTIONS") {
    return new Response("OK", {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type"
      }
    });
  }
  try {
    const body = await req.json();
    const { concept, direction, target, purpose, price, benchmark, others, knowledgeBase } = body;
    const systemPrompt = `\uB2F9\uC2E0\uC740 '\uC870\uC26C\uC758 \uCF58\uD150\uCE20 \uB9C8\uC2A4\uD130\uD074\uB798\uC2A4'\uC758 \uC218\uC11D \uCF58\uD150\uCE20 \uAE30\uD68D\uC790\uC785\uB2C8\uB2E4.
\uC218\uAC15\uC0DD\uC758 \uACC4\uC815 \uC815\uBCF4\uB97C \uBD84\uC11D\uD558\uACE0, [\uC9C0\uC2DD \uBCA0\uC774\uC2A4]\uC5D0 \uB2F4\uAE34 \uC870\uC26C\uC758 \uCCA0\uD559\uACFC \uBC29\uBC95\uB860\uC744 \uBC14\uD0D5\uC73C\uB85C \uAC00\uC7A5 \uC2E4\uC9C8\uC801\uC774\uACE0 \uB0A0\uCE74\uB85C\uC6B4 \uC804\uB7B5\uC744 \uC81C\uC548\uD574\uC57C \uD569\uB2C8\uB2E4.

[\uC218\uAC15\uC0DD \uACC4\uC815 \uC815\uBCF4]
- \uACC4\uC815 \uCEE8\uC149 \uBC0F \uC8FC\uC81C: ${concept}
- \uACE0\uBBFC \uBC0F \uC6B4\uC601 \uBC29\uD5A5\uC131: ${direction}
- \uD0C0\uAC9F \uACE0\uAC1D: ${target}
- \uBAA9\uD45C\uD558\uB294 \uC804\uD658/\uD6A8\uACFC: ${purpose}
- \uD310\uB9E4 \uC0C1\uD488 \uBC0F \uAC00\uACA9\uB300: ${price}
- \uBCA4\uCE58\uB9C8\uD0B9 \uC2A4\uD0C0\uC77C: ${benchmark}
- \uAE30\uD0C0 \uC694\uCCAD\uC0AC\uD56D: ${others || "\uC5C6\uC74C"}

[\uCD9C\uB825 \uAC00\uC774\uB4DC\uB77C\uC778]
\uBC18\uB4DC\uC2DC \uB2E4\uC74C 4\uAC00\uC9C0 \uD56D\uBAA9\uC744 \uD3EC\uD568\uD558\uC5EC \uD48D\uBD80\uD558\uACE0 \uC0C1\uC138\uD558\uAC8C \uC791\uC131\uD574\uC8FC\uC138\uC694.
- **\uC911\uC694**: \uC808\uB300 \uC774\uBAA8\uC9C0(Emoji)\uB97C \uC0AC\uC6A9\uD558\uC9C0 \uB9C8\uC138\uC694.
- **\uC911\uC694**: \uC808\uB300 \uBCFC\uB4DC\uCCB4(**) \uB4F1 \uB9C8\uD06C\uB2E4\uC6B4 \uAC15\uC870 \uAE30\uD638\uB97C \uC0AC\uC6A9\uD558\uC9C0 \uB9C8\uC138\uC694. \uC624\uC9C1 \uD3C9\uBB38\uC73C\uB85C\uB9CC \uC791\uC131\uD558\uC138\uC694.
- **\uC911\uC694**: \uB2F5\uBCC0\uC740 \uC624\uC9C1 \uC81C\uACF5\uB41C [\uC9C0\uC2DD \uBCA0\uC774\uC2A4]\uC758 \uCCA0\uD559\uC744 \uAE30\uBC18\uC73C\uB85C \uC791\uC131\uD574\uC57C \uD569\uB2C8\uB2E4.

1. \uD0C0\uAC9F \uACE0\uAC1D\uC758 \uC9C4\uC9DC \uD398\uC778 \uD3EC\uC778\uD2B8 \uC9C4\uB2E8
2. \uB2F9\uC7A5 \uC4F8 \uC218 \uC788\uB294 \uCD94\uCC9C \uD6C4\uD0B9 \uC8FC\uC81C 3\uAC00\uC9C0
3. \uCD5C\uC801\uC758 \uCF58\uD150\uCE20 \uD3EC\uB9F7 \uC81C\uC548 (\uC2A4\uD1A0\uB9AC\uD154\uB9C1/\uC815\uBCF4\uC131/\uAC10\uC131 \uC911 \uD0DD 1\uACFC \uADF8 \uC774\uC720)
4. \uB79C\uB529\uD398\uC774\uC9C0 \uC720\uC785 \uBC0F \uC804\uD658 \uC2DC\uB098\uB9AC\uC624

[\uC9C0\uC2DD \uBCA0\uC774\uC2A4]
${knowledgeBase || "\uC9C0\uC2DD \uBCA0\uC774\uC2A4 \uC815\uBCF4\uAC00 \uC5C6\uC2B5\uB2C8\uB2E4."}`;
    const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
    const result = await model.generateContentStream(systemPrompt);
    const stream = new ReadableStream({
      async start(controller) {
        try {
          for await (const chunk of result.stream) {
            const chunkText = chunk.text();
            controller.enqueue(new TextEncoder().encode(chunkText));
          }
          controller.close();
        } catch (e) {
          controller.error(e);
        }
      }
    });
    return new Response(stream, {
      headers: {
        "Content-Type": "text/plain; charset=utf-8",
        "Access-Control-Allow-Origin": "*"
      }
    });
  } catch (error) {
    console.error("Planner Error:", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" }
    });
  }
};
export {
  planner_default as default
};
